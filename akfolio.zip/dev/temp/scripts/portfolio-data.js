var projects =[{  
      name:"Website Sample 1",
      thumbnail:"assets/images/portfolio/portfolio_01.jpg",
      description:"Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte.",
      image:"assets/images/portfolio/screenshot_01.jpg",
      liveLink:"",
      category:"webdesign"
   },

   {  
      name:"Website Sample 2",
      thumbnail:"assets/images/portfolio/portfolio_02.jpg",
      description:"Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte.",
      image:"assets/images/portfolio/screenshot_02.jpg",
      liveLink:"",
      category:"webdesign"
   },
   {  
      name:"Graphic Sample 1",
      thumbnail:"assets/images/portfolio/graphic_thumb.jpg",
      description:"Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte.",
      image:"assets/images/portfolio/graphic_01.jpeg",
      liveLink:"",
      category:"graphic"
   },
   {  
      name:"Logo Sample 1",
      thumbnail:"assets/images/portfolio/logo_thumb.jpg",
      description:"Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte.",
      image:"assets/images/portfolio/logo_01.jpeg",
      liveLink:"",
      category:"logo"
   },
   {  
      name:"Graphic Sample 2",
      thumbnail:"assets/images/portfolio/graphic_02_thumb.jpg",
      description:"Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte.",
      image:"assets/images/portfolio/graphic_02.jpeg",
      liveLink:"",
      category:"graphic"
   },
   {  
      name:"Graphic Sample 3",
      thumbnail:"assets/images/portfolio/graphic_03_thumb.jpg",
      description:"Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte.",
      image:"assets/images/portfolio/graphic_03.jpeg",
      liveLink:"",
      category:"graphic"
   }
];